import express, {Router} from "express";
import userController from "./controllers/user";

import moscow from "./controllers/methods/moscow";
import kano from "./controllers/methods/kano_model";
import rice from "./controllers/methods/rice";
import ai from "./controllers/methods/ai";
import backlog from "./controllers/backlog";
import task from "./controllers/task";
import atlassian from "./controllers/atlassian";
import auth from "./controllers/sign-in";



const router: Router = express.Router();

//sign-in
router.post("/auth", auth.signIn);

//users
router.get("/users/:id", userController.readUserByID);
router.post("/users", userController.createUser);

//prioritize
router.post("/prioritize/moscow", moscow.moscowPriorization);
router.post("/prioritize/kano", kano.kanoModelPriorization);
router.post("/prioritize/rice", rice.ricePriorization);
router.post("/prioritize/ai", ai.getAIPriorization);

//backlogs
router.get("/backlogs/:user_id", backlog.getBackLogs);
router.get("/backlogs/single/:id", backlog.getOneBackLog);
router.get("/backlogs/:id/tasks", backlog.getTasksFromBacklog);
router.post("/backlogs", backlog.createBacklog);

//tasks
router.post("/tasks", task.createTask);

//atlassian
router.get("/atlassian/oauth", atlassian.atlassianOAuth);
router.get("/atlassian/projects/:user_id", atlassian.getJiraProjects);
router.get("/atlassian/projects/:user_id/:project_id", atlassian.getJiraProjectTasks);

export default router;
