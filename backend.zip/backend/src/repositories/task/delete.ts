import database from "../../database/connection"

export async function deleteTask(id: string) {
  try {
    await database.query({
      query: `
            DELETE FROM \`task\` 
            WHERE \`id\` = ?
            ;
            `,
      values: [id],
    })
    return
  } catch (error: Error | any) {
    throw error
  }
}
