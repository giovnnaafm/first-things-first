import database from "../../database/connection";
import {Task} from "../../models/task";

export async function createTask(taskData: Task) {
  try {
    const databaseValue: Task[] = await database.query({
      query: `
            INSERT INTO \`task\` 
              (\`id\`, \`title\`,  \`description\`, \`backlog_id\`, 
              \`impact\`, \`priority\`, \`due_time\`, \`estimative\`,
              \`reach\`, \`confidence\`, \`kano\`, \`moscow\`, 
              \`status\`, \`created_at\`, \`updated_at\`) 
            VALUES 
              ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ;
            `,
      values: [
        taskData.id,
        taskData.title,
        taskData.description,
        taskData.backlog_id,
        taskData.impact,
        taskData.priority,
        taskData.due_time,
        taskData.estimative,
        taskData.reach,
        taskData.confidence,
        taskData.kano,
        taskData.moscow,
        taskData.status,
        taskData.created_at,
        taskData.updated_at,
      ],
    });
    return databaseValue[0] || null;
  } catch (error: Error | any) {
    console.log(error)
    throw error;
  }
}
