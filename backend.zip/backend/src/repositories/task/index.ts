import {createTask} from "./create";
import {deleteTask} from "./delete";
import {updateTask} from "./update";
import {readTaskByID} from "./read";

export const task = {
  createTask,
  deleteTask,
  updateTask,
  readTaskByID,
};
