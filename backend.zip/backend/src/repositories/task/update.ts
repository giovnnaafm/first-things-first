import database from "../../database/connection"
import { Task } from "../../models/task"

export async function updateTask(id:string, taskData: Task) {
  try {
    const databaseValue: Task[] = await database.query({
      query: `
            UPDATE \`task\` 
            SET   \`title\` = ?,  \`description\` = ?, \`impact\` = ?, \'priority\' = ?, \'due_time\' = ?, \'estimative\' = ?) 
            WHERE  \`id\` = ?
            ;
            `,
      values: [
        taskData.title,
        taskData.description,
        taskData.impact,
        taskData.priority,
        taskData.due_time,
        taskData.estimative,
        id
      ],
    })
    return databaseValue[0] || null
  } catch (error: Error | any) {
    throw error
  }
}
