import database from "../../database/connection"
import {Task} from "../../models/task"

export async function readTaskByID(id: string): Promise<Task | null> {
  try {
    const databaseValue: Task[] = await database.query({
      query: `
            SELECT * FROM \`task\` 
             WHERE \'id\' = ?
            ;`,
            values: [id],
    })
    return databaseValue[0]
  } catch (error: Error | any) {
    throw error
  }
}

