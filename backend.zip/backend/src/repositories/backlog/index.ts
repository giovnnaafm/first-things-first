import {createBacklog} from "./create";
import {deleteBacklog} from "./delete";
import {updateBacklog} from "./update";
import {
  readAllBacklogs,
  readBacklogByID,
  readAllTasksByBacklogID,
} from "./read";

export const backlog = {
  createBacklog,
  deleteBacklog,
  updateBacklog,
  readAllBacklogs,
  readBacklogByID,
  readAllTasksByBacklogID,
};
