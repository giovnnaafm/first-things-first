import database from "../../database/connection";
import {Backlog} from "../../models/backlog";
import {Task} from "../../models/task";

export async function readAllBacklogs(
  user_id: string
): Promise<Backlog[] | undefined> {
  try {
    const databaseValue: Backlog[] = await database.query({
      query: `
            SELECT * FROM \`backlog\` 
            WHERE \`user_id\` = ?
            ;`,
      values: [user_id],
    });
    return databaseValue;
  } catch (error: Error | any) {
    throw error;
  }
}

export async function readBacklogByID(id: string): Promise<Backlog | null> {
  try {
    const databaseValue: Backlog[] = await database.query({
      query: `
          SELECT * FROM \`backlog\` 
          WHERE \`id\` = ?
          ;
          `,
      values: [id],
    });
    return databaseValue[0];
  } catch (error: Error | any) {
    throw error;
  }
}

export async function readAllTasksByBacklogID(
  backlog_id: string
): Promise<Task[] | null> {
  try {
    const databaseValue: Task[] = await database.query({
      query: `
          SELECT * FROM \`task\` 
          WHERE \`backlog_id\` = ?
          ;
          `,
      values: [backlog_id],
    });
    return databaseValue;
  } catch (error: Error | any) {
    throw error;
  }
}
