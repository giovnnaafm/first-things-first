import database from "../../database/connection";
import {Backlog} from "../../models/backlog";

export async function createBacklog(backlogData: Backlog): Promise<Backlog> {
  try {
    const databaseValue: Backlog[] = await database.query({
      query: `
            INSERT INTO \`backlog\` 
              (\`id\`, \`name\`,  \`priorization_method\`, \`user_id\`, \`jira\`, \`created_at\`, \`updated_at\`) 
            VALUES 
              ( ?, ?, ?, ?, ?, ?, ?)
            ;`,
      values: [
        backlogData.id,
        backlogData.name,
        backlogData.priorization_method,
        backlogData.user_id,
        backlogData.jira,
        backlogData.created_at, 
        backlogData.updated_at
      ],
    });
    return backlogData;
  } catch (error: Error | any) {
    throw error;
  }
}
