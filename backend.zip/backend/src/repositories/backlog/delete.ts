import database from "../../database/connection";

export async function deleteBacklog(id: string) {
  try {
    await database.query({
      query: `
            DELETE FROM \`backlog\` 
            WHERE \`id\` = ?
            ;
            `,
      values: [id],
    });
    return;
  } catch (error: Error | any) {
    throw error;
  }
}
