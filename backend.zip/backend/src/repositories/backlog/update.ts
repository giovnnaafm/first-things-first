import database from "../../database/connection";
import {Backlog} from "../../models/backlog";

export async function updateBacklog(
  id: string,
  newBacklog: Backlog
): Promise<Backlog | undefined> {
  try {
    const databaseValue: Backlog[] = await database.query({
      query: `
            UPDATE \`backlog\`
            SET \`name\` = ?, \`priorization_method\` = ?
            WHERE \`id\` = ?
            ;`,
      values: [newBacklog.name, newBacklog.priorization_method, id],
    });
    return databaseValue[0];
  } catch (error: Error | any) {
    throw error;
  }
}
