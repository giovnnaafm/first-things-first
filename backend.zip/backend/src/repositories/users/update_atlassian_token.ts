import database from "../../database/connection";
import {User} from "../../models/user";

export async function updateUserAtlassianToken(
  id: string,
  token: string | null
): Promise<User | undefined> {
  try {
    const now = new Date();
    const databaseValue: User[] = await database.query({
      query: `
          UPDATE \`user\` 
          SET \`atlassian_access_token\`= ?, \`atlassian_token_updated_at\`= ?
          WHERE \`email\` = ?
        ;`,
      values: [token, now, id],
    });
    return databaseValue[0];
  } catch (error: Error | any) {
    throw error;
  }
}
