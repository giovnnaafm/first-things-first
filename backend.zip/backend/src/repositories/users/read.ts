import database from "../../database/connection"
import { User } from "../../models/user"

export async function readUserByID(id: string): Promise<User | undefined> {
    try {
      const databaseValue: User[] = await database.query({
        query: `
            SELECT * 
            FROM \`user\` 
            WHERE \`email\` = ?
            ;
            `,
        values: [id],
      })
      return databaseValue[0]
    } catch (error: Error | any) {
      throw error
    }
  }