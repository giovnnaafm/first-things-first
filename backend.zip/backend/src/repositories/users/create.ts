import database from '../../database/connection'
import { User } from '../../models/user'

export async function createUser(userData: User): Promise<User | null> {
  try {
    const databaseValue: User[] = await database.query({
      query: `
        INSERT INTO \`user\` 
          (\`email\`, \`name\`, \`password_hash\`) 
        VALUES 
          (?, ?, ?)
        ;`,
      values: [userData.email, userData.name, userData.password_hash]
    })
    return databaseValue[0] || null
  } catch (error: Error | any) {
    throw error
  }
}
