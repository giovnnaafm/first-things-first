import database from "../../database/connection"
import { User } from "../../models/user"

export async function updateUserCloudID(id:string, email:string): Promise<User | undefined> {
    try {
      const databaseValue: User[] = await database.query({
        query: `
          UPDATE \`user\` 
          SET \`atlassian_cloud_id\`= ?
          WHERE \`email\` = ?
        ;`,
        values: [id, email],
      })
      return databaseValue[0]
    } catch (error: Error | any) {
      throw error
    }
  }