import {users as repository} from "../../repositories/users";
import {User} from "../../models/user";
import {isTokenExpired} from "../../utils/is_token_expired";
import {updateUserAtlassianToken} from "./update_user_atlassian_token";

export async function readUserByID(
  userID: string | undefined
): Promise<User | undefined> {
  try {
    if (!userID) return undefined;
    const user = await repository.readUserByID(userID);
    if (
      user?.atlassian_access_token?.length &&
      isTokenExpired(user?.atlassian_token_updated_at)
    ) {
      updateUserAtlassianToken(userID, null);
    }
    return user;
  } catch (error: Error | any) {
    throw error;
  }
}
