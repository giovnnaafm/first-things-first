import {users as repository} from "../../repositories/users";
import {User} from "../../models/user";

export async function createUser(
  user:User
): Promise<User | null> {
  try {
    if (!user) return null;
    return await repository.createUser(user);
  } catch (error: Error | any) {
    throw error;
  }
}
