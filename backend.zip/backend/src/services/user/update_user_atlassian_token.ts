import {users as repository} from "../../repositories/users";
import {User} from "../../models/user";

export async function updateUserAtlassianToken(
    userID:string,
    token:string | null
): Promise<User | undefined> {
  try {
    if (!userID) return undefined;
    return await repository.updateUserAtlassianToken(userID, token);
  } catch (error: Error | any) {
    throw error;
  }
}
