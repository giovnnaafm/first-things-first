import { createUser } from "./create_user";
import { readUserByID } from "./read_user";

export const user = {
    readUserByID,
    createUser
}