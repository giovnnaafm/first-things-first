import { readUserByID } from "../user/read_user";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken"

interface SignInData {
  username: string;
  password: string;
}
export async function signInUser(
  signInData: SignInData
): Promise<string | undefined> {
  try {
    const userData = await readUserByID(signInData.username);
    if (!userData) return undefined;
    const claims = {
      email: userData.email,
      name: userData.name,
      secret_token: userData.atlassian_access_token,
      cloud_id: userData.atlassian_cloud_id,
    };
    const secret = process.env.SECRET_TOKEN || "default_secret";
    const token = jwt.sign(claims, secret, { algorithm: "HS256" });
    return token;
  } catch (error) {
    throw error;
  }
}
