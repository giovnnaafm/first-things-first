import { signInUser } from "./sign-in";

export const auth = {signInUser}