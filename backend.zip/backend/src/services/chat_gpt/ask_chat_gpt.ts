import {ChatBotMessage, ChatGPTAPIRequest} from "../../models/chat_bot_message";
import chatGPTApiRequest from "./chat_gpt";

export default async function askToChatBot(
  content: ChatBotMessage[],
  model: string,
  temperature: number,
  isJson: boolean
): Promise<string> {
  const chatContent: ChatGPTAPIRequest = {
    model: model,
    temperature: temperature,
    messages: content,
    response_format: isJson ? {type: "json_object"} : undefined,
  };

  try {
    const responseContent = await chatGPTApiRequest(
      "POST",
      "/completions",
      chatContent
    );
    let contentResponse = "";
    for (const choice of responseContent.choices) {
      contentResponse += choice.message.content;
    }
    return contentResponse;
  } catch (error) {
    throw error;
  }
}
