const axios = require("axios");

import {ChatGPTAPIRequest} from "../../models/chat_bot_message";

export default async function chatGPTApiRequest(
  method: string,
  chatGPTAPIPath: string,
  contentData: ChatGPTAPIRequest
) {
  try {
    const response = await axios({
      method: method,
      url: `https://api.openai.com/v1/chat${chatGPTAPIPath}`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.CHAT_GPT_API_KEY}`,
      },
      data: contentData,
    });

    return response.data;
  } catch (error: Error | any) {
    throw new Error(`Error on OpenAI API request: ${error.message}`);
  }
}
