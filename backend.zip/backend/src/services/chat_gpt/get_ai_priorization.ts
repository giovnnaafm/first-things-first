import {ChatBotMessage} from "../../models/chat_bot_message";
import {Task} from "../../models/task";
import askToChatBot from "./ask_chat_gpt";

export type ResponseFormat = {justification: string; tasks: string[]};

export default async function getAIPriorization(
  id: string,
  tasks: Task[]
): Promise<ResponseFormat> {
  try {
    const jsonToString = JSON.stringify(tasks);
    const prompt = `
      You are a task prioritizer. You will receive an array of objects that represent tasks. Each object has the following structure:
  
      id: a string that identifies the task.
      backlog_id: a string that identifies the task's backlog.
      title: a string that is the task's title.
      description: an optional string that describes the task.
      due_time: a date that represents the task's deadline.
      impact: a string that can be "High", "Medium", or "Low", indicating the task's impact.
      estimative: an optional string that estimates the time needed to complete the task.
      status: a string that represents the task's status.
  
      Your task is to reorder this array of tasks by priority. You are free to use any prioritization criteria you deem best, such as due time, impact, description, or any other relevant factor.
  
      You must not have only eyes for "impact" or "due_time", but also consider your interpretation of the context that the title and description gives you.
  
      However, it is MANDATORY that you return ONLY (with no additional words) the result in JSON format with the following keys:
  
      justification: A DETAILED justification for the prioritization order chosen, here you'll have to tell the user why you chose this order or tasks. Remember that its EXTREMELY IMPORTANT that you justification is cohesive, it's the user work we are talking about. Do NOT write in the first person. And it is MANDATORY that the justification be in English. Do NOT expose the tasks ID here, its not relevant for the user.
      tasks: The array of ONLY THE "id" value of each of the tasks ordered according to your prioritization.
      
      in the structure above, YOU MUST ONLY return de IDs array in tasks, and NEVER create a new ID.
    
      Please follow these instructions and provide the result in the requested format. 
      HERE ARE THE UNPRIORITIZED TASKS:
      ${jsonToString}
  
    `;

    const content: ChatBotMessage[] = [
      {
        content: prompt,
        name: `chat_${id}`,
        role: "system",
      },
    ];
    const responseFromAI = await askToChatBot(content, "gpt-4o", 0.8, true);
    const jsonResponse: ResponseFormat = JSON.parse(responseFromAI);
    return jsonResponse;
  } catch (error) {
    return {justification: "", tasks: []};
  }
}
