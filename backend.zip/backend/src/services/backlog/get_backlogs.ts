import { backlog as repository } from '../../repositories/backlog'
import { Backlog } from '../../models/backlog'

export async function getBackLog(id:string): Promise<Backlog | null> {
  try {
    return await repository.readBacklogByID(id)
  } catch (error: Error | any) {
    throw error
  }
}

export async function getBackLogs(id:string): Promise<Backlog[] | undefined> {
  try {
    return await repository.readAllBacklogs(id)
  } catch (error: Error | any) {
    throw error
  }
}