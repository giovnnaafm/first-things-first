import {backlog as repository} from "../../repositories/backlog";
import {Backlog} from "../../models/backlog";

export async function createBacklog(
  backLogData: Backlog | undefined
): Promise<Backlog | undefined> {
  try {
    if (!backLogData) throw new Error("no backlog data provided");
    const now = new Date();
    backLogData.created_at = now;
    backLogData.updated_at = now;
    return await repository.createBacklog(backLogData);
  } catch (error: Error | any) {
    throw error;
  }
}
