import {createBacklog} from "./create_backlog";
import {getBackLogs, getBackLog} from "./get_backlogs";
import {getTasksFromBacklog} from "./get_tasks_from_backlog";

export const backlog = {
  createBacklog,
  getBackLogs,
  getBackLog,
  getTasksFromBacklog,
};
