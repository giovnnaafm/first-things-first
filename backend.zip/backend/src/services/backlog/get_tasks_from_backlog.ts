import {backlog as repository} from "../../repositories/backlog";
import {Task} from "../../models/task";
import {getBackLog} from "./get_backlogs";
import {prioritize} from "../../utils/select_priorization";

export async function getTasksFromBacklog(id: string): Promise<Task[] | null> {
  try {
    const tasks = await repository.readAllTasksByBacklogID(id);
    const backlog = await getBackLog(id);
    if (!backlog?.priorization_method || backlog.priorization_method == "AI" || !tasks) return tasks;
    return prioritize(backlog?.priorization_method, tasks);
  } catch (error: Error | any) {
    throw error;
  }
}
