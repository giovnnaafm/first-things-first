import axios from "axios";
import {updateUserAtlassianToken} from "../user/update_user_atlassian_token";
import getCloudID from "./get_cloud_id";
import {updateUserCloudID} from "../../repositories/users/update_atlassian_cloud_id";

export default async function createAccessToken(
  code: string,
  email: string
): Promise<string> {
  try {
    const response = await axios.post(
      "https://auth.atlassian.com/oauth/token",
      {
        grant_type: "authorization_code",
        client_id: process.env.ATLASSIAN_CLIENT_ID,
        client_secret: process.env.ATLASSIAN_SECRET_ID,
        code,
        redirect_uri: "http://localhost:9000/v1/atlassian/oauth",
      },
      {headers: {"Content-Type": "application/json"}}
    );
    const token = response.data.access_token;
    if (token) await updateUserAtlassianToken(email, token);
    const cloudID = await getCloudID(token);
    if (cloudID) await updateUserCloudID(cloudID, email);
    return "Autenthicated";
  } catch (error) {
    throw error;
  }
}
