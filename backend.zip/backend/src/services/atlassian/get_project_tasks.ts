import axios from "axios";
import {User} from "../../models/user";
import {JiraTask} from "../../models/atlassian";

export default async function getProjectTasks(
  projectKey: string,
  user: User
): Promise<JiraTask[]> {
  try {
    if (!user.atlassian_access_token || !user.atlassian_cloud_id) {
      throw new Error("No Atlassian OAuth access token or cloud id");
    }
    const response = await axios.get(
      `https://api.atlassian.com/ex/jira/${user.atlassian_cloud_id}/rest/api/3/search`,
      {
        headers: {
          Authorization: `Bearer ${user.atlassian_access_token}`,
          Accept: "application/json",
        },
        params: {
          jql: `project = ${projectKey}`,
        },
      }
    );
    const tasks:JiraTask[] = response.data.issues;
    return tasks;
  } catch (error) {
    throw error;
  }
}
