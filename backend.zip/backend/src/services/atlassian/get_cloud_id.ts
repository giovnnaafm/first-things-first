import axios from "axios";

export default async function getCloudID(token: string):Promise<string>{
  try {
    const response = await axios.get(
      "https://api.atlassian.com/oauth/token/accessible-resources",
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      }
    );
    const id = response.data[0].id;
    return id
  } catch (error) {
    throw error;
  }
}
