import axios from "axios";
import {User} from "../../models/user";

export default async function getProjects(user: User) {
  try {
    if (!user.atlassian_access_token || !user.atlassian_cloud_id) {
      throw new Error("No Atlassian OAuth access token");
    }

    const response = await axios.get(
      `https://api.atlassian.com/ex/jira/${user.atlassian_cloud_id}/rest/api/3/project/search`,
      {
        headers: {
          Authorization: `Bearer ${user.atlassian_access_token}`,
          Accept: "application/json",
        },
      }
    );
    return response.data.values
  } catch (error) {
    throw error;
  }
}
