import createAccessToken from "./create_access_token";
import getProjectTasks from "./get_project_tasks";
import getProjects from "./get_projects";

export const atlassian = {
    getProjects,
    getProjectTasks,
    createAccessToken
}