import { createTask } from "./create_task";

export const task = {
    createTask
}