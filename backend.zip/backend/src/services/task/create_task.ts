import {task as repository} from "../../repositories/task";
import { Task } from "../../models/task";

export async function createTask(
  taskData: Task | undefined
): Promise<Task | undefined> {
  try {
    if (!taskData) throw new Error("no task data provided");
    const now = new Date();
    taskData.created_at = now;
    taskData.updated_at = now;
    return await repository.createTask(taskData);
  } catch (error: Error | any) {
    throw error;
  }
}
