export function estimativeParser(estimative: string): number {
  const unit = estimative.slice(-1);
  const value = parseInt(estimative.slice(0, -1), 10);

  switch (unit) {
    case "h":
      return value * 60;
    case "d":
      return value * 1440;
    case "w":
      return value * 10080;
    default:
      return value;
  }
}
