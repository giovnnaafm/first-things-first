import { Task } from "../models/task";

export function cleanTaskData(tasks: Task[]): Task[]{
    tasks.map((task) => {
        task.moscow = undefined
        task.kano = undefined
    })
    return tasks
}