import {MoSCoW} from "../../models/methods";
import {Task} from "../../models/task";
import {estimativeParser} from "../estimative_parser";

export function prioritizeTasksMoSCoW(tasks: Task[]): Task[] {
  const moscowPriorityOrder: MoSCoW[] = [
    "Must Have",
    "Should Have",
    "Could Have",
    "Wont Have",
  ];

  return tasks
    .sort((a, b) => {
      const moscowPriorityA = moscowPriorityOrder.indexOf(
        a.moscow!
      );
      const moscowPriorityB = moscowPriorityOrder.indexOf(
        b.moscow!
      );

      if (moscowPriorityA !== moscowPriorityB) {
        return moscowPriorityA - moscowPriorityB;
      }
      const impactOrder: Record<string, number> = {High: 1, Medium: 2, Low: 3};
      const impactA = impactOrder[a.impact];
      const impactB = impactOrder[b.impact];

      if (impactA !== impactB) {
        return impactA - impactB;
      }

      const estimativeA = a.estimative
        ? estimativeParser(a.estimative)
        : Infinity;
      const estimativeB = b.estimative
        ? estimativeParser(b.estimative)
        : Infinity;

      return estimativeA - estimativeB;
    });
}
