import {Task} from "../../models/task";
import {estimativeParser} from "../estimative_parser";

export function calculateRICEScore(
  reach: number,
  impact: number,
  confidence: number,
  effort: number
): number {
  return (reach * impact * confidence) / effort;
}

export function prioritizeTasksRICE(tasks: Task[]): Task[] {
  return tasks.sort((a, b) => {
    const impactValues: Record<string, number> = {High: 3, Medium: 2, Low: 1};
    const effortA = a.estimative ? estimativeParser(a.estimative) : Infinity;
    const effortB = b.estimative ? estimativeParser(b.estimative) : Infinity;
    const riceA = calculateRICEScore(a.reach, impactValues[a.impact], a.confidence, effortA);
    const riceB = calculateRICEScore(b.reach, impactValues[b.impact], b.confidence, effortB);
    return riceB - riceA;
  });
}
