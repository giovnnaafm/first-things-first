import {KanoCategory} from "../../models/methods";
import {Task} from "../../models/task";
import {estimativeParser} from "../estimative_parser";

export function prioritizeTasksKano(tasks: Task[]): Task[] {
  const kanoPriorityOrder: KanoCategory[] = [
    "Must-be",
    "One-Dimensional",
    "Attractive",
    "Indifferent",
    "Reverse",
  ];

  return tasks
    .sort((a, b) => {
      const kanoPriorityA = kanoPriorityOrder.indexOf(
        a.kano!
      );
      const kanoPriorityB = kanoPriorityOrder.indexOf(
        b.kano!
      );

      if (kanoPriorityA !== kanoPriorityB) {
        return kanoPriorityA - kanoPriorityB;
      }

      const impactOrder: Record<string, number> = {High: 1, Medium: 2, Low: 3};
      const impactA = impactOrder[a.impact];
      const impactB = impactOrder[b.impact];

      if (impactA !== impactB) {
        return impactA - impactB;
      }

      const estimativeA = a.estimative
        ? estimativeParser(a.estimative)
        : Infinity;
      const estimativeB = b.estimative
        ? estimativeParser(b.estimative)
        : Infinity;

      return estimativeA - estimativeB;
    });
}
