export function isTokenExpired(tokenDate: Date | undefined): boolean {
    if(!tokenDate) return false
    const now = new Date().getTime();
    const tokenTime = tokenDate.getTime(); 
    const difference = (now - tokenTime) / 1000; 
    return difference > 3600;
}