import {Error, HttpErrorResponse} from "../models/error";

const success = (payload: any): Object => {
  const response: any = {
    success: true,
    payload,
  };
  if (!payload) {
    delete response.payload;
  }
  return response;
};

const error = (error: Error): HttpErrorResponse => ({
  success: false,
  error: {
    message: error.errorMessage ? error.errorMessage.toUpperCase() : null,
    details: error.errorDetails
      ? String(error.errorDetails).toUpperCase()
      : null,
  },
});

export function newError(
  httpCode: number,
  message: string,
  error?: any
): Error {
  return {
    httpCode,
    errorMessage: message,
    errorDetails: error ? error || error.message : undefined,
  };
}

export const httpResponse = {success, error, newError};
