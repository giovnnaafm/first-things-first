import { Task } from "../models/task";
import { prioritizeTasksKano } from "./priorization_methods/kano";
import { prioritizeTasksMoSCoW } from "./priorization_methods/moscow";
import { prioritizeTasksRICE } from "./priorization_methods/rice";

export function prioritize(method:string, tasks:Task[]):Task[] | null {
    method = method.toLocaleLowerCase()
    switch(method) {
        case "moscow": 
            return prioritizeTasksMoSCoW(tasks)
        case "kano":
            return prioritizeTasksKano(tasks)
        case "rice":
            return prioritizeTasksRICE(tasks)
        default:
            return null
    }
}