import {Request, Response} from "express";
import {atlassian as service} from "../services/atlassian";
import {httpResponse} from "../utils/http_response_formatter";
import {readUserByID} from "../services/user/read_user";

async function atlassianOAuth(req: Request, res: Response): Promise<void> {
  try {
    const {code, user_email} = req.query;
    if (typeof code !== "string" || typeof user_email !== "string")
      throw new Error("No query code or user provided");
    await service.createAccessToken(code, user_email);
    res.redirect('http://localhost:3000/backlogs/create');    
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function getJiraProjects(req: Request, res: Response): Promise<void> {
  try {
    const {user_id} = req.params;
    const user = await readUserByID(user_id);
    if (!user) throw new Error();
    const response = await service.getProjects(user);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function getJiraProjectTasks(req: Request, res: Response): Promise<void> {
  try {
    const {user_id, project_id} = req.params;
    const user = await readUserByID(user_id);
    if (!user) throw new Error();
    const response = await service.getProjectTasks(project_id, user);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default {getJiraProjects, getJiraProjectTasks, atlassianOAuth};
