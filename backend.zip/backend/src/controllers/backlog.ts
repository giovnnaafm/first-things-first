import {Request, Response} from "express";
import {backlog as service} from "../services/backlog";
import {httpResponse, newError} from "../utils/http_response_formatter";
import {Backlog} from "../models/backlog";
import {v4 as uuid} from "uuid";
import {Task} from "../models/task";

async function createBacklog(req: Request, res: Response): Promise<void> {
  try {
    const body: Backlog | undefined = req.body;
    if (!body) throw new Error("body not provided");
    body.id = uuid();
    const response: Backlog | undefined = await service.createBacklog(body);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function getBackLogs(req: Request, res: Response): Promise<void> {
  try {
    const { user_id } = req.params
    if(!user_id) throw new Error
    const response: Backlog[] | undefined = await service.getBackLogs(user_id);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function getOneBackLog(req: Request, res: Response): Promise<void> {
  try {
    const {id} = req.params;
    const response: Backlog | null = await service.getBackLog(id);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function getTasksFromBacklog(req: Request, res: Response): Promise<void> {
  try {
    const {id} = req.params;
    if (!id) return;
    const response: Task[] | null = await service.getTasksFromBacklog(id);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default {createBacklog, getBackLogs, getOneBackLog, getTasksFromBacklog};
