import {Request, Response} from "express";
import {user as service} from "../services/user";
import {User} from "../models/user";
import {httpResponse, newError} from "../utils/http_response_formatter";

async function readUserByID(req: Request, res: Response): Promise<void> {
  try {
    const {id} = req.params;
    if (!id) throw newError(400, "no id provided");
    const response: User | undefined = await service.readUserByID(id);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

async function createUser(req: Request, res: Response): Promise<void> {
  try {
    const body = req.body;
    if (!body) throw newError(400, "no id provided");
    const response: User | null = await service.createUser(body);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default {readUserByID, createUser};
