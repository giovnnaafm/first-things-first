import {Request, Response} from "express";
import {auth as service} from "../services/auth";
import { httpResponse } from "../utils/http_response_formatter";

async function signIn(req: Request, res: Response): Promise<void> {
  try {
    const body = req.body;
    if (!body) throw new Error("body not provided");
    const response: string | undefined = await service.signInUser(body);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default { signIn }