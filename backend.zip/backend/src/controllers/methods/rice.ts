import {Request, Response} from "express";

import {httpResponse, newError} from "../../utils/http_response_formatter";
import { prioritizeTasksRICE } from "../../utils/priorization_methods/rice";

import {Task} from "../../models/task";

async function ricePriorization(req: Request, res: Response): Promise<void> {
  try {
    const body = req.body;
    if (!body || !Array.isArray(body)) {
      throw newError(400, "Invalid body provided, expected an array of tasks");
    }
    const tasks: Task[] = body;
    const response: Task[] | undefined = await prioritizeTasksRICE(tasks);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default { ricePriorization };
