import {Request, Response} from "express";

import {httpResponse, newError} from "../../utils/http_response_formatter";
import prioritize, {
  ResponseFormat,
} from "../../services/chat_gpt/get_ai_priorization";

import {Task} from "../../models/task";
import {v4 as uuid} from "uuid";
import { cleanTaskData } from "../../utils/clean_task_data";

type ResponseType = {
  justification: string;
  tasks: Task[];
};
async function getAIPriorization(req: Request, res: Response): Promise<void> {
  try {
    const body = req.body;
    if (!body) {
      throw newError(400, "Invalid body provided, expected an array of tasks");
    }
    const tasks: Task[] = body;
    const cleanedTasks = cleanTaskData(tasks)
    const id = uuid();
    const response: ResponseFormat | undefined = await prioritize(id, cleanedTasks);
    const apiResponse: ResponseType = {
      justification: response.justification,
      tasks: reorderTasks(tasks, response.tasks),
    };
    res.status(200).send(httpResponse.success(apiResponse));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export function reorderTasks(
  tasks: Task[],
  priorizedTasksIds: string[]
): Task[] {
  const taskMap = new Map(tasks.map((task) => [task.id, task]));

  const reorderedTasks = priorizedTasksIds
    .map((id) => taskMap.get(id))
    .filter((task) => task !== undefined) as Task[];

  return reorderedTasks;
}

export default {getAIPriorization};
