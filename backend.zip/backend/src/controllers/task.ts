import {Request, Response} from "express";
import {task as service} from "../services/task";
import {httpResponse, newError} from "../utils/http_response_formatter";
import {v4 as uuid} from "uuid";
import {Task} from "../models/task";

async function createTask(req: Request, res: Response): Promise<void> {
  try {
    const data: Task = req.body;
    if (!data) return;
    data.id = uuid();
    const response: Task | undefined = await service.createTask(data);
    res.status(200).send(httpResponse.success(response));
  } catch (error: Error | any) {
    res.status(500).send(httpResponse.error(error));
  }
}

export default {createTask};
