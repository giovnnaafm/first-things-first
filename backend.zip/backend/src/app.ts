import express, {Express, Request, Response} from "express";
import cors from "cors";
import router from "./router";

const app: Express = express();

app.get("/", (req: Request, res: Response) => {
  res.json({service: `First things First - version 1.0`});
});
app.use(cors());
app.use(express.json());
app.use("/v1", router);

export default app;
