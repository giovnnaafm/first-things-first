import {KanoCategory, MoSCoW, Rice} from "./methods";

export interface Task {
  id: string;
  backlog_id: string;
  title: string;
  description?: string;
  due_time?: Date;
  impact: "High" | "Medium" | "Low";
  priority?: number;
  estimative?: string;
  status?: "To do" | "Completed" | "In Progress" | "On Hold";
  moscow?: MoSCoW;
  kano?: KanoCategory;
  reach: number;
  confidence: number;
  created_at: Date;
  updated_at: Date;
}
