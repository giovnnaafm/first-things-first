export interface ChatBotMessage {
  role: string;
  name: string;
  content: string;
}

export interface ChatGPTAPIRequest {
  model: string;
  response_format?: {
    type: string;
  };
  temperature: number;
  messages: ChatBotMessage[];
}
