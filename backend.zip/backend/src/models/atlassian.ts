export interface JiraTask {
    id: string;
    key: string;
    fields: {
      statuscategorychangedate: string;
      issuetype: {
        id: string;
        description: string;
        name: string;
        subtask: boolean;
        hierarchyLevel: number;
      };
      timespent: number | null;
      project: {
        id: string;
        key: string;
        name: string;
        projectTypeKey: string;
        simplified: boolean;
      };
      fixVersions: any[];
      aggregatetimespent: number | null;
      resolution: string | null;
      workratio: number;
      watches: {
        watchCount: number;
        isWatching: boolean;
      };
      lastViewed: string;
      created: string;
      priority: {
        name: string;
        id: string;
      };
      labels: string[];
      timeestimate: number | null;
      aggregatetimeoriginalestimate: number | null;
      versions: any[];
      issuelinks: any[];
      assignee: string | null;
      updated: string;
      status: {
        id: string;
        name: string;
        description: string;
      };
    };
  }