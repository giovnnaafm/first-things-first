type PriorizationMehod = "MoSCoW" | "Kano" | "Rice" | "AI";
export interface Backlog {
  id: string;
  name: string;
  priorization_method: PriorizationMehod;
  user_id: string;
  jira?: boolean;
  created_at?: Date;
  updated_at?: Date;
}
