export interface User {
  email: string;
  name: string;
  password_hash: string;
  atlassian_access_token?: string;
  atlassian_cloud_id?: string;
  created_at: Date;
  atlassian_token_updated_at: Date;
}
