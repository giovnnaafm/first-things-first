export interface Error {
    httpCode: number;
    errorMessage: string | null;
    errorDetails: string | null;
  }
  
  export interface HttpErrorResponse {
    success: false,
    error: {
      message: string | null,
      details: string | null,
    }
  }