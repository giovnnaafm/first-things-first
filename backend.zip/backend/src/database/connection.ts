import {escape, MysqlError, createPool, Pool} from "mysql";

type Query = {
  query: string;
  values?: Object | null;
};

const pool: Pool = createPool({
  connectionLimit: 10,
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  insecureAuth: true,
});

/**
 * Execute query
 * @param {Query} queries
 */
const query = (queries: Query): Promise<any> =>
  new Promise((resolve: any, reject: any): void => {
    pool.query(
      queries.query,
      queries.values,
      (error: MysqlError | null, results: any): void => {
        if (error) {
          reject(error.message);
        }
        resolve(results);
      }
    );
  });

const truncateAllTables = (): Promise<any> =>
  new Promise((resolve: any, reject: any): void => {
    pool.query(
      "CALL truncate_all_tables();",
      null,
      (error: MysqlError | null, results: any): void => {
        if (error) {
          reject(error.message);
        }
        resolve(true);
      }
    );
  });

const database = {pool, query, escape, truncateAllTables};

export default database;
